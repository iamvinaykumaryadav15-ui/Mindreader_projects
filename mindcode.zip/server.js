require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const braintree = require('braintree');
const Razorpay = require('razorpay');
const geoip = require('geoip-lite');

// --- DEVELOPMENT SETTING: Change this to test different gateways ---
// true = Show Razorpay (India) on localhost
// false = Show Braintree (International) on localhost

const IS_LOCAL_TESTING_INDIA = false;

const app = express();
const port = 3000;

// --- MIDDLEWARE SETUP ---
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({ secret: process.env.SESSION_SECRET || 'super-secret-key', resave: false, saveUninitialized: true, cookie: { secure: false } }));
app.use(passport.initialize());
app.use(passport.session());
app.enable('trust proxy');

// --- DATABASE CONNECTION ---
const db = mysql.createPool({
    host: process.env.DB_HOST, user: process.env.DB_USER,
    password: process.env.DB_PASSWORD, database: process.env.DB_NAME,
    waitForConnections: true, connectionLimit: 10, queueLimit: 0
}).promise();
db.getConnection().then(() => console.log('MySQL Connected...')).catch(err => console.error('Error connecting to MySQL:', err));

// --- PAYMENT GATEWAY SETUP ---
const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
});
const braintreeGateway = new braintree.BraintreeGateway({
    environment: braintree.Environment.Sandbox,
    merchantId: process.env.BRAINTREE_MERCHANT_ID,
    publicKey: process.env.BRAINTREE_PUBLIC_KEY,
    privateKey: process.env.BRAINTREE_PRIVATE_KEY
});

// --- PASSPORT.JS (GOOGLE AUTH) SETUP ---
passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: "/auth/google/callback"
}, async (accessToken, refreshToken, profile, done) => {
    try {
        const email = profile.emails[0].value;
        const googleId = profile.id;
        let [users] = await db.query('SELECT * FROM users WHERE googleId = ?', [googleId]);
        if (users.length > 0) { return done(null, users[0]); }
        else {
            let [existingEmail] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
            if (existingEmail.length > 0) {
                await db.query('UPDATE users SET googleId = ? WHERE email = ?', [googleId, email]);
                let [updatedUser] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
                return done(null, updatedUser[0]);
            } else {
                const [result] = await db.query('INSERT INTO users (email, googleId) VALUES (?, ?)', [email, googleId]);
                const newUser = { id: result.insertId, email, googleId, credits: 0, has_unlimited: false };
                return done(null, newUser);
            }
        }
    } catch (err) { return done(err, null); }
}));
passport.serializeUser((user, done) => { done(null, user.id); });
passport.deserializeUser(async (id, done) => {
    try {
        const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [id]);
        done(null, rows.length > 0 ? rows[0] : false);
    } catch (err) { done(err, null); }
});

// --- ROUTES ---
app.get('/', (req, res) => {
    const { error, message, payment } = req.query;
    const ip = req.ip;
    let country;
    if (ip === '::1' || ip === '127.0.0.1') {
        country = IS_LOCAL_TESTING_INDIA ? 'IN' : 'US';
    } else {
        const geo = geoip.lookup(ip);
        country = (geo && geo.country) ? geo.country : 'US';
    }
    res.render('index', { user: req.user, error, message, payment, country });
});

app.get('/client_token', (req, res) => {
    braintreeGateway.clientToken.generate({}, (err, response) => {
        if (err) { res.status(500).send(err); } 
        else { res.send(response.clientToken); }
    });
});

// --- AUTH ROUTES ---
app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
app.get('/auth/google/callback', passport.authenticate('google', { failureRedirect: '/?error=Google login failed' }), (req, res) => { res.redirect('/'); });
app.post('/register', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.redirect('/?error=Email and password are required.');
        if (password.length < 6) return res.redirect('/?error=Password must be at least 6 characters long.');
        const hashedPassword = await bcrypt.hash(password, 10);
        await db.query('INSERT INTO users (email, password) VALUES (?, ?)', [email, hashedPassword]);
        res.redirect('/?message=Registration successful! Please login.');
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') res.redirect('/?error=Email already exists.');
        else res.redirect('/?error=An error occurred during registration.');
    }
});
app.post('/login', async (req, res, next) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.redirect('/?error=Email and password are required.');
        const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        if (rows.length > 0) {
            const user = rows[0];
            if (!user.password) return res.redirect('/?error=Please login using your Google account.');
            const match = await bcrypt.compare(password, user.password);
            if (match) {
                req.login(user, (err) => { if (err) { return next(err); } return res.redirect('/'); });
            } else { res.redirect('/?error=Incorrect password.'); }
        } else { res.redirect('/?error=User not found.'); }
    } catch (error) { res.redirect('/?error=An error occurred during login.'); }
});
app.get('/logout', (req, res, next) => {
    req.logout((err) => { if (err) { return next(err); } res.redirect('/'); });
});

// --- PAYMENT ROUTES ---
const planDetails = {
    IN: { currency: 'INR', plans: { '5': 7, '9': 15, '49': 100, '99': 500, '499': -1 } },
    US: { currency: 'USD', plans: { '1': 7, '2': 15, '5': 100, '10': 500, '50': -1 } }
};
app.post('/create-order', async (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'You must be logged in.' });
    const { amount } = req.body;
    const ip = req.ip;
    let country;
    if (ip === '::1' || ip === '127.0.0.1') {
        country = IS_LOCAL_TESTING_INDIA ? 'IN' : 'US';
    } else {
        const geo = geoip.lookup(ip);
        country = (geo && geo.country) ? geo.country : 'US';
    }

    if (country === 'IN') {
        try {
            const countryPlans = planDetails['IN'];
            const credits = countryPlans.plans[amount];
            const options = { amount: amount * 100, currency: "INR", notes: { userId: req.user.id, credits } };
            const order = await razorpay.orders.create(options);
            return res.json({ gateway: 'razorpay', order });
        } catch (error) { return res.status(500).json({ error: 'Error creating Razorpay order.' }); }
    } else {
         return res.json({ gateway: 'braintree' });
    }
});
app.post('/checkout', async (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'You must be logged in.' });
    const { amount, paymentMethodNonce } = req.body;
    const countryPlans = planDetails['US'];
    const credits = countryPlans.plans[amount];
    braintreeGateway.transaction.sale({
        amount: amount, paymentMethodNonce: paymentMethodNonce,
        options: { submitForSettlement: true }
    }, async (err, result) => {
        if (err || !result.success) {
            console.error("Braintree Error:", result.message || err);
            return res.status(500).json({ error: 'Braintree transaction failed.' });
        }
        try {
            if (credits === -1) {
                await db.query('UPDATE users SET has_unlimited = TRUE WHERE id = ?', [req.user.id]);
            } else {
                await db.query('UPDATE users SET credits = credits + ? WHERE id = ?', [credits, req.user.id]);
            }
             const [[user]] = await db.query('SELECT credits, has_unlimited FROM users WHERE id = ?', [req.user.id]);
            const newCreditValue = user.has_unlimited ? 'Unlimited' : user.credits;
            if(req.user) req.user.credits = newCreditValue;
            res.json({ success: true, newCredits: newCreditValue });
        } catch (dbError) {
            res.status(500).json({ error: 'Failed to update credits after payment.' });
        }
    });
});

// --- GAME LOGIC ROUTE ---
app.post('/play-game', async (req, res) => {
    if (!req.user) return res.status(401).json({ success: false, message: 'You must be logged in.' });
    try {
        const [[user]] = await db.query('SELECT credits, has_unlimited FROM users WHERE id = ?', [req.user.id]);
        if (user.has_unlimited) { return res.json({ success: true, newCredits: 'Unlimited' }); }
        if (user.credits > 0) {
            await db.query('UPDATE users SET credits = credits - 1 WHERE id = ?', [req.user.id]);
            const newCredits = user.credits - 1;
            if(req.user) req.user.credits = newCredits;
            return res.json({ success: true, newCredits: newCredits });
        } else {
            return res.json({ success: false, message: 'You have no credits left.' });
        }
    } catch (error) {
        console.error('Error deducting credit:', error);
        return res.status(500).json({ success: false, message: 'A server error occurred.' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

