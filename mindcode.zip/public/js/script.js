document.addEventListener('DOMContentLoaded', () => {
    // --- Section 1: All Variable Declarations & Initializations ---
    const isUserLoggedIn = document.querySelector('.welcome-message');
    
    // Modals
    const authModal = document.getElementById('authModal');
    const rechargeModal = document.getElementById('rechargeModal');
    const sideMenu = document.getElementById('sideMenu');
    const aboutModal = document.getElementById('aboutModal');
    const disclaimerModal = document.getElementById('disclaimerModal');

    // Buttons that open things
    const loginButton = document.getElementById('loginButton');
    const buyCreditsBtn = document.getElementById('buyCreditsBtn');
    const menuBtn = document.getElementById('menuBtn');
    const footerAboutLink = document.getElementById('footerAboutLink');
    const footerDisclaimerLink = document.getElementById('footerDisclaimerLink');
    const sideMenuAboutLink = document.getElementById('sideMenuAboutLink');
    const sideMenuDisclaimerLink = document.getElementById('sideMenuDisclaimerLink');
    
    // A robust way to select all close buttons
    const allCloseButtons = document.querySelectorAll('.close-button');

    // Auth Modal specifics
    const tabLinks = document.querySelectorAll('.tab-link');
    const tabContents = document.querySelectorAll('.tab-content');
    
    // Recharge Modal specifics
    const plansContainer = document.querySelector('.plans-container');
    const braintreeContainer = document.getElementById('braintree-dropin-container');

    // Game elements
    const steps = [
        "Close your eyes and think of a number.", "Now, Multiply it by 2.", "Now, add a random even number to your total.", "Now, divide your total by 2.", "Finally, subtract the original number you imagined.", "The number in your mind is..."
    ];
    let currentStep = -1;
    let isMuted = false;
    const instructions = document.getElementById('instructions');
    const nextButton = document.getElementById('nextButton');
    const muteButton = document.getElementById('muteButton');
    const magicSound = document.getElementById('magicSound');
    const finalMusic = document.getElementById('finalMusic');
    let random = 0;

    // --- Section 2: Modal and Menu Logic ---
    if (loginButton) loginButton.addEventListener('click', () => { if(authModal) authModal.style.display = 'flex'; });
    if (buyCreditsBtn) buyCreditsBtn.addEventListener('click', () => { populatePaymentPlans(); if(rechargeModal) rechargeModal.style.display = 'flex'; });
    if (menuBtn) menuBtn.addEventListener('click', () => { if(sideMenu) sideMenu.style.width = '250px'; });
    if (footerAboutLink) footerAboutLink.addEventListener('click', (e) => { e.preventDefault(); if(aboutModal) aboutModal.style.display = 'flex'; });
    if (footerDisclaimerLink) footerDisclaimerLink.addEventListener('click', (e) => { e.preventDefault(); if(disclaimerModal) disclaimerModal.style.display = 'flex'; });
    if (sideMenuAboutLink) sideMenuAboutLink.addEventListener('click', (e) => { e.preventDefault(); if(aboutModal) aboutModal.style.display = 'flex'; if(sideMenu) sideMenu.style.width = '0'; });
    if (sideMenuDisclaimerLink) sideMenuDisclaimerLink.addEventListener('click', (e) => { e.preventDefault(); if(disclaimerModal) disclaimerModal.style.display = 'flex'; if(sideMenu) sideMenu.style.width = '0'; });

    allCloseButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal-overlay, .side-menu');
            if (modal) {
                if(modal.classList.contains('side-menu')) {
                    modal.style.width = '0';
                } else {
                    modal.style.display = 'none';
                    if (modal.id === 'rechargeModal') resetRechargeModal();
                }
            }
        });
    });
    
    window.addEventListener('click', (event) => {
        if (event.target.classList.contains('modal-overlay')) {
            event.target.style.display = 'none';
            if (event.target.id === 'rechargeModal') resetRechargeModal();
        }
    });
    
    tabLinks.forEach(tab => {
        tab.addEventListener('click', () => {
            tabLinks.forEach(item => item.classList.remove('active'));
            tabContents.forEach(item => item.classList.remove('active'));
            tab.classList.add('active');
            document.getElementById(tab.dataset.tab).classList.add('active');
        });
    });
    
    function resetRechargeModal() {
        if(plansContainer) plansContainer.style.display = 'grid';
        if(braintreeContainer) {
            braintreeContainer.innerHTML = '';
            braintreeContainer.style.display = 'none';
        }
    }

    // --- Section 3: Smart Payment Logic ---
    function populatePaymentPlans() {
        resetRechargeModal();
        const planDetails = {
            IN: { currency: '₹', plans: [{ amount: 5, credits: 7 }, { amount: 9, credits: 15 }, { amount: 49, credits: 100, p: true }, { amount: 99, credits: 500 }, { amount: 499, credits: 'Unlimited', v: true }] },
            US: { currency: '$', plans: [{ amount: 1, credits: 7 }, { amount: 2, credits: 15 }, { amount: 5, credits: 100, p: true }, { amount: 10, credits: 500 }, { amount: 50, credits: 'Unlimited', v: true }] }
        };
        const countryConfig = planDetails[userCountry] || planDetails['US'];
        
        if(plansContainer) plansContainer.innerHTML = '';
        
        countryConfig.plans.forEach(plan => {
            const card = document.createElement('div');
            card.className = 'plan-card';
            if (plan.p) card.classList.add('popular');
            if (plan.v) card.classList.add('vip');
            card.dataset.amount = plan.amount;
            card.innerHTML = `Buy ${plan.credits} Credits for ${countryConfig.currency}${plan.amount}` + (plan.p ? `<span>Most Popular</span>` : '');
            if(plansContainer) plansContainer.appendChild(card);
        });

        document.querySelectorAll('.plan-card').forEach(card => card.addEventListener('click', handlePlanClick));
    }

    async function handlePlanClick(event) {
        const card = event.currentTarget;
        const amount = card.dataset.amount;

        const response = await fetch('/create-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ amount })
        });
        const data = await response.json();

        if (data.error) { return alert(data.error); }

        if (data.gateway === 'razorpay') {
            const options = {
                key: razorpayKeyId, amount: data.order.amount, currency: data.order.currency,
                name: "Mind Reader Game", order_id: data.order.id,
                handler: () => { window.location.href = '/?payment=success&message=Credits Added!'; },
                prefill: { email: userEmail }
            };
            const rzp = new Razorpay(options);
            rzp.open();
        } else if (data.gateway === 'braintree') {
            if(plansContainer) plansContainer.style.display = 'none';
            if(braintreeContainer) braintreeContainer.style.display = 'block';
            initializeBraintree(amount);
        }
    }
    
    function initializeBraintree(amount) {
        fetch('/client_token').then(res => res.text()).then(clientToken => {
            if(braintreeContainer) braintreeContainer.innerHTML = '';
            braintree.dropin.create({
                authorization: clientToken,
                container: '#braintree-dropin-container',
                paypal: { flow: 'checkout', amount: amount, currency: 'USD' }
            }, (createErr, instance) => {
                if (createErr) { console.error(createErr); if(braintreeContainer) braintreeContainer.innerHTML = 'Error loading payment form.'; return; }
                
                const payButton = document.createElement('button');
                payButton.textContent = `Pay`;
                payButton.className = 'button';
                if(braintreeContainer) braintreeContainer.appendChild(payButton);

                payButton.addEventListener('click', () => {
                    payButton.disabled = true;
                    instance.requestPaymentMethod((reqErr, payload) => {
                        if (reqErr) {
                            console.error(reqErr);
                            payButton.disabled = false;
                            alert('Could not process payment method. Please try again.');
                            return;
                        }
                        fetch('/checkout', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ amount: amount, paymentMethodNonce: payload.nonce })
                        })
                        .then(res => res.json())
                        .then(result => {
                            if (result.success) {
                                alert('Payment successful! Your credits have been updated.');
                                window.location.reload();
                            } else {
                                alert(result.error || 'Payment failed. Please try again.');
                                payButton.disabled = false;
                            }
                        });
                    });
                });
            });
        });
    }

    // --- Section 4: Game Logic ---
    async function handleNextStep() {
        const creditDisplay = document.getElementById('creditDisplay');
        if (currentStep === -1) {
            if (isUserLoggedIn) {
                const response = await fetch('/play-game', { method: 'POST' });
                const data = await response.json();
                if (data.success) {
                    if (creditDisplay) creditDisplay.textContent = `Your Credits: ${data.newCredits}`;
                    currentStep++;
                    updateGameUI();
                } else {
                    populatePaymentPlans();
                    if (rechargeModal) rechargeModal.style.display = 'flex';
                }
            } else {
                const hasPlayed = localStorage.getItem('mindReaderFreePlay');
                if (hasPlayed) {
                    if (authModal) authModal.style.display = 'flex';
                } else {
                    localStorage.setItem('mindReaderFreePlay', 'true');
                    currentStep++;
                    updateGameUI();
                }
            }
        } else {
            currentStep++;
            updateGameUI();
        }
    }
    
    function updateGameUI() {
        if (currentStep >= steps.length) {
            currentStep = -1;
            instructions.textContent = "Press \"Start\" to begin.";
            if (nextButton.querySelector('span')) nextButton.querySelector('span').textContent = "Start";
            instructions.classList.remove('final-animation');
            return;
        }
        if (nextButton.querySelector('span')) nextButton.querySelector('span').textContent = 'Next';
        if (currentStep === 2) {
            random = getRandomEvenNumber();
            instructions.textContent = `Now, add ${random} to your total.`;
        } else if (currentStep === steps.length - 1) {
            const magic = random / 2;
            instructions.innerHTML = `<span class="final-animation">The Number in Your Mind is ${magic}!</span>`;
            if (!isMuted && finalMusic) finalMusic.play();
            if (nextButton.querySelector('span')) nextButton.querySelector('span').textContent = "Restart";
        } else {
            instructions.textContent = steps[currentStep];
            if (currentStep > 0 && !isMuted && magicSound) magicSound.play();
        }
    }
    function toggleMute() { isMuted = !isMuted; if (document.getElementById('volumeIcon')) document.getElementById('volumeIcon').className = isMuted ? 'fas fa-volume-mute' : 'fas fa-volume-up'; }
    function getRandomEvenNumber() { let num; do { num = Math.floor(Math.random() * 50) * 2; } while (num === 0); return num; }

    // --- Section 5: Initializations ---
    function setRandomBackground() { if(document.getElementById('background-animation')) document.getElementById('background-animation').classList.add('bg-animation-1'); }
    if (nextButton) nextButton.addEventListener('click', handleNextStep);
    if (muteButton) muteButton.addEventListener('click', toggleMute);
    setRandomBackground();
    if (typeof particlesJS === 'function') {
        particlesJS('particles-js', { "particles": { "number": { "value": 40, "density": { "enable": true, "value_area": 800 } }, "color": { "value": "#ffffff" }, "shape": { "type": "circle" }, "opacity": { "value": 0.5, "random": true }, "size": { "value": 2, "random": true }, "line_linked": { "enable": true, "distance": 150, "color": "#ffffff", "opacity": 0.2, "width": 1 }, "move": { "enable": true, "speed": 1, "direction": "none", "out_mode": "out" } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "repulse" }, "onclick": { "enable": false } }, "modes": { "repulse": { "distance": 100 } } }, "retina_detect": true });
    }
});

